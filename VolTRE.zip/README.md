# VolTRE
Playground for volume based sampling method for timed regular expressions.

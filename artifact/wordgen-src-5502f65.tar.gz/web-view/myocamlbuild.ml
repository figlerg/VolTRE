let () = Ocamlbuild_plugin.Options.use_ocamlfind := true

(*let () = Ocamlbuild_plugin.dispatch Ocamlbuild_js_of_ocaml.dispatcher*)

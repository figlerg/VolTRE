module type FSIG = sig
  type t

  val equal : t -> t -> bool
  val zero : t
  val one : t
  val minus_one : t
  val infinity : t
  val neg : t -> t
  val add : t -> t -> t
  val sub : t -> t -> t
  val mul : t -> t -> t
  val powi : t -> int -> t
  val div : t -> t -> t
  val max : t -> t -> t
  val of_int : int -> t
  val to_int : t -> int
  val to_string : t -> string
  val of_float : float -> t
  val to_float : t -> float
  val is_integer : t -> bool
  val is_exact : bool
end

module Float : FSIG = struct
  include Float

  let zero = 0.0
  let one = 1.0
  let minus_one = -1.0
  let max x y = max x y
  let to_float x = x
  let of_float x = x
  let powi x i = pow x (float i)
  let is_integer x = x = floor x
  let is_exact = false
end

//This file was generated from (Academic) UPPAAL 4.1.26 (rev. C3644FEF32EA19FE), December 2021

/*

*/
Pr[<=10](<> Process.p2)

/*

*/
Pr[<=10](<> Process.p1)
